module.exports = require("nativescript-dev-sass/lib/before-watchPatterns.js");
